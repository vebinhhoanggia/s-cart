
##========= History =========

Version 4.x support S-Cart 6.x

Version 5.x support S-Cart 7.x


Login facebook, github, google S-Cart

==Please config value from file .env===

GITHUB_CLIENT_ID=
GITHUB_CLIENT_SECRET=
GITHUB_REDIRECT=

FACEBOOK_APP_ID=
FACEBOOK_APP_SECRET=
FACEBOOK_APP_CALLBACK_URL=

GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
GOOGLE_REDIRECT=


Link: https://s-cart.org/en/plugin/login-socialite_15980250855f3fed7da2123.html