<?php
return [
    'title'      => 'LoginSocialite',
    'email_can_not_empty' => 'Email cannot empty!',
    'email_exist' => 'Email already exists!',
    'admin'      => [
        'title'          => 'LoginSocialite',
    ],
];
