<?php
return [
    'title'      => 'LoginSocialite',
    'email_exist' => 'Email đã tồn tại!',
    'email_can_not_empty' => 'Email không thể rỗng!',
    'admin'      => [
        'title'          => 'LoginSocialite',
    ],
];
